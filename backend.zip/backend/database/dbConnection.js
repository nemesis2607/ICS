import mongoose from "mongoose";

export const dbConnection = () => {
  const uri = process.env.MONGO_URI;
  console.log('MONGO_URI:', uri); // Debugging log to verify MONGO_URI

  if (!uri) {
    console.error("Error: MONGO_URI is not defined in environment variables.");
    return;
  }

  mongoose
    .connect(uri, {
      dbName: "Immigration_Consultancy_Management",
    })
    .then(() => {
      console.log("Connected to database!");
    })
    .catch((err) => {
      console.error("Some error occurred while connecting to database:", err);
    });
};
