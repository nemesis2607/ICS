import express from "express";
import { dbConnection } from "./database/dbConnection.js";
import { config } from "dotenv"; // Import dotenv
import cookieParser from "cookie-parser";
import cors from "cors";
import fileUpload from "express-fileupload";
import { errorMiddleware } from "./middlewares/error.js";
import messageRouter from "./router/messageRouter.js";
import userRouter from "./router/userRouter.js";
import appointmentRouter from "./router/appointmentRouter.js";

// Load environment variables from config.env file
config({ path: "./config.env" });

// Debugging logs to verify environment variables
console.log('Loaded environment variables:');
console.log('PORT:', process.env.PORT);
console.log('MONGO_URI:', process.env.MONGO_URI);
console.log('FRONTEND_URL_ONE:', process.env.FRONTEND_URL_ONE);
console.log('FRONTEND_URL_TWO:', process.env.FRONTEND_URL_TWO);
console.log('JWT_SECRET_KEY:', process.env.JWT_SECRET_KEY);
console.log('JWT_EXPIRES:', process.env.JWT_EXPIRES);
console.log('COOKIE_EXPIRE:', process.env.COOKIE_EXPIRE);
console.log('CLOUDINARY_CLOUD_NAME:', process.env.CLOUDINARY_CLOUD_NAME);
console.log('CLOUDINARY_API_KEY:', process.env.CLOUDINARY_API_KEY);
console.log('CLOUDINARY_API_SECRET:', process.env.CLOUDINARY_API_SECRET);

const app = express();

app.use(
  cors({
    origin: [process.env.FRONTEND_URL_ONE, process.env.FRONTEND_URL_TWO],
    methods: ["GET", "POST", "DELETE", "PUT"],
    credentials: true,
  })
);

app.use(cookieParser());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(
  fileUpload({
    useTempFiles: true,
    tempFileDir: "/tmp/",
  })
);

app.use("/api/v1/message", messageRouter);
app.use("/api/v1/user", userRouter);
app.use("/api/v1/appointment", appointmentRouter);

dbConnection();

app.use(errorMiddleware);

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Server listening at port ${PORT}`);
});

export default app;
